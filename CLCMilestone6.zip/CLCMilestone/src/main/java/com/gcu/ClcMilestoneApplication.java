package com.gcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClcMilestoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClcMilestoneApplication.class, args);
	}

}
